RESET BUTTON - UPLOAD INSTRUCTIONS

1. Go to Netlify Drop.
2. Drag this ZIP file onto the upload box.
3. Netlify gives you a live link.
4. Test it on your phone.
5. Share the link.

Privacy: static site; no hidden tracking; saves only in browser when user clicks save.
